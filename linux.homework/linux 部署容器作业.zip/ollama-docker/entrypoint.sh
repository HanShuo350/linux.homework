#!/bin/bash

ollama serve &

sleep 5

echo "正在拉取 qwen3:0.6B 模型..."
ollama pull qwen3:0.6B

wait